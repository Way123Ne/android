package net.sourceforge.simcpux;

public class Constants {
	// APP_ID 替换为你的应用从官方网站申请到的合法appId==
    public static final String APP_ID = "wx1b73fd7b49ffa027";
    
    public static class ShowMsgActivity {
		public static final String STitle = "showmsg_title";
		public static final String SMessage = "showmsg_message";
		public static final String BAThumbData = "showmsg_thumb_data";
	}
}
